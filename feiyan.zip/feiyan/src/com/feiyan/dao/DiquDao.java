package com.feiyan.dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.feiyan.util.DBUtil;
import com.feiyan.been.DiquBeen;


public class DiquDao {
//	public static void main(String [] args)
//	{
//		String emphasis="����";
//		DiquDao dao=new DiquDao();
//		List<DiquBeen> list=dao.find(emphasis);
//	}

	public List<DiquBeen> find(String emphasis)
	{
	
		String sql="select * from diqu where emphasis='"+emphasis+"'";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		ResultSet rs = null;
		
		List<DiquBeen> list=new ArrayList<>();
		DiquBeen been=null;
		try {	
			state = conn.createStatement();
			rs = state.executeQuery(sql);
			while (rs.next()) {
				String name=rs.getString("name");
				String totalconfirm=rs.getString("totalconfirm");
				String todayconfirm=rs.getString("todayconfirm");
				String totalheal=rs.getString("totalheal");
				String totaldead=rs.getString("totaldead");
				
				//System.out.println(name);
				
				been =new DiquBeen(name,totalconfirm,todayconfirm,totalheal,totaldead);
				list.add(been);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, state, conn);
		}
		return list;
			}
	
}
