package com.feiyan.dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.feiyan.util.DBUtil;
import com.feiyan.been.ShengBeen;


public class ShengDao {
	

	public List<ShengBeen> find()
	{
		String sql="select * from feiyansheng";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		ResultSet rs = null;
		
		List<ShengBeen> list=new ArrayList<>();
		ShengBeen been=null;
		try {	
			state = conn.createStatement();
			rs = state.executeQuery(sql);
			while (rs.next()) {
				String name=rs.getString("name");
				String value=rs.getString("totalconfirm");
				//System.out.println(name);
				
				been =new ShengBeen(name,value);
				list.add(been);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, state, conn);
		}
		return list;
			}
	
}
