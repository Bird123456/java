package com.feiyan.been;

public class DiquBeen {

	private String name;
	private String totalconfirm;
	private String todayconfirm;
	private String totalheal;
	private String totaldead;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTotalconfirm() {
		return totalconfirm;
	}
	public void setTotalconfirm(String totalconfirm) {
		this.totalconfirm = totalconfirm;
	}
	public String getTodayconfirm() {
		return todayconfirm;
	}
	public void setTodayconfirm(String todayconfirm) {
		this.todayconfirm = todayconfirm;
	}
	public String getTotalheal() {
		return totalheal;
	}
	public void setTotalheal(String totalheal) {
		this.totalheal = totalheal;
	}
	public String getTotaldead() {
		return totaldead;
	}
	public void setTotaldead(String totaldead) {
		this.totaldead = totaldead;
	}
	public DiquBeen(String name, String totalconfirm, String todayconfirm, String totalheal, String totaldead) {
		super();
		this.name = name;
		this.totalconfirm = totalconfirm;
		this.todayconfirm = todayconfirm;
		this.totalheal = totalheal;
		this.totaldead = totaldead;
	}
	
}
