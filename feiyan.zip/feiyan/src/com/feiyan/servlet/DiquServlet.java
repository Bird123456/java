package com.feiyan.servlet;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServlet;

import com.google.gson.*;
import com.feiyan.been.DiquBeen;
import com.feiyan.dao.DiquDao;

@WebServlet("/DiquServlet")
public class DiquServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	
	DiquDao dao=new DiquDao();
	
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		String method = req.getParameter("method");
		if ("find".equals(method)) {
			
			find(req, resp);
		}
	}
	
	private void find(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		req.setCharacterEncoding("utf-8");
		
		Gson gson = new Gson();
		String json=null;//��ʼ��json
		String emphasis = req.getParameter("name");
		//System.out.println("diqu"+emphasis);
		List<DiquBeen> list=dao.find(emphasis);//dao�㷵�ص�����
		
		json = gson.toJson(list);//Ϊjson��ֵ
		System.out.println("���ص�ֵ"+json);
		// ��json�ַ������ݷ��ظ�ǰ��
		resp.setContentType("text/html; charset=utf-8");
		resp.getWriter().write(json);
	}
}
