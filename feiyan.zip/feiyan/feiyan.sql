/*
Navicat MySQL Data Transfer

Source Server         : 192.168.43.112
Source Server Version : 50173
Source Host           : 192.168.43.112:3306
Source Database       : feiyan

Target Server Type    : MYSQL
Target Server Version : 50173
File Encoding         : 65001

Date: 2020-06-01 15:46:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for diqu
-- ----------------------------
DROP TABLE IF EXISTS `diqu`;
CREATE TABLE `diqu` (
  `name` varchar(255) DEFAULT NULL,
  `totalconfirm` varchar(255) DEFAULT NULL,
  `todayconfirm` varchar(255) DEFAULT NULL,
  `totalheal` varchar(255) DEFAULT NULL,
  `totaldead` varchar(255) DEFAULT NULL,
  `emphasis` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of diqu
-- ----------------------------
INSERT INTO `diqu` VALUES ('武汉', '45027', '615', '5448', '1585', '湖北');
INSERT INTO `diqu` VALUES ('孝感', '3329', '0', '673', '89', '湖北');
INSERT INTO `diqu` VALUES ('黄冈', '2839', '0', '1149', '87', '湖北');
INSERT INTO `diqu` VALUES ('荆州', '1510', '0', '451', '40', '湖北');
INSERT INTO `diqu` VALUES ('鄂州', '1338', '0', '350', '38', '湖北');
INSERT INTO `diqu` VALUES ('随州', '1283', '3', '308', '27', '湖北');
INSERT INTO `diqu` VALUES ('襄阳', '1167', '2', '294', '23', '湖北');
INSERT INTO `diqu` VALUES ('黄石', '967', '0', '299', '26', '湖北');
INSERT INTO `diqu` VALUES ('宜昌', '891', '0', '231', '27', '湖北');
INSERT INTO `diqu` VALUES ('荆门', '794', '0', '201', '34', '湖北');
INSERT INTO `diqu` VALUES ('咸宁', '766', '0', '268', '10', '湖北');
INSERT INTO `diqu` VALUES ('十堰', '641', '3', '187', '2', '湖北');
INSERT INTO `diqu` VALUES ('仙桃', '567', '5', '184', '19', '湖北');
INSERT INTO `diqu` VALUES ('天门', '473', '0', '133', '12', '湖北');
INSERT INTO `diqu` VALUES ('恩施州', '244', '0', '102', '3', '湖北');
INSERT INTO `diqu` VALUES ('潜江', '185', '0', '49', '7', '湖北');
INSERT INTO `diqu` VALUES ('神农架', '10', '0', '10', '0', '湖北');
INSERT INTO `diqu` VALUES ('深圳', '416', '0', '182', '2', '广东');
INSERT INTO `diqu` VALUES ('广州', '339', '0', '158', '0', '广东');
INSERT INTO `diqu` VALUES ('珠海', '98', '0', '45', '1', '广东');
INSERT INTO `diqu` VALUES ('东莞', '92', '1', '26', '1', '广东');
INSERT INTO `diqu` VALUES ('佛山', '84', '0', '33', '0', '广东');
INSERT INTO `diqu` VALUES ('中山', '66', '0', '42', '0', '广东');
INSERT INTO `diqu` VALUES ('惠州', '62', '0', '38', '0', '广东');
INSERT INTO `diqu` VALUES ('汕头', '25', '0', '18', '0', '广东');
INSERT INTO `diqu` VALUES ('江门', '23', '0', '9', '0', '广东');
INSERT INTO `diqu` VALUES ('湛江', '22', '0', '11', '0', '广东');
INSERT INTO `diqu` VALUES ('肇庆', '18', '0', '8', '1', '广东');
INSERT INTO `diqu` VALUES ('梅州', '16', '0', '10', '0', '广东');
INSERT INTO `diqu` VALUES ('茂名', '14', '0', '6', '0', '广东');
INSERT INTO `diqu` VALUES ('阳江', '13', '0', '9', '0', '广东');
INSERT INTO `diqu` VALUES ('清远', '12', '0', '9', '0', '广东');
INSERT INTO `diqu` VALUES ('韶关', '10', '0', '5', '0', '广东');
INSERT INTO `diqu` VALUES ('揭阳', '8', '0', '4', '0', '广东');
INSERT INTO `diqu` VALUES ('汕尾', '5', '0', '2', '0', '广东');
INSERT INTO `diqu` VALUES ('潮州', '5', '0', '3', '0', '广东');
INSERT INTO `diqu` VALUES ('河源', '4', '0', '1', '0', '广东');
INSERT INTO `diqu` VALUES ('地区待确认', '0', '0', '0', '0', '广东');
INSERT INTO `diqu` VALUES ('信阳', '269', '1', '28', '3', '河南');
INSERT INTO `diqu` VALUES ('郑州', '156', '1', '36', '1', '河南');
INSERT INTO `diqu` VALUES ('南阳', '155', '0', '28', '2', '河南');
INSERT INTO `diqu` VALUES ('驻马店', '139', '0', '25', '0', '河南');
INSERT INTO `diqu` VALUES ('商丘', '91', '0', '9', '1', '河南');
INSERT INTO `diqu` VALUES ('周口', '76', '0', '16', '0', '河南');
INSERT INTO `diqu` VALUES ('平顶山', '58', '0', '13', '1', '河南');
INSERT INTO `diqu` VALUES ('新乡', '57', '0', '6', '1', '河南');
INSERT INTO `diqu` VALUES ('安阳', '53', '1', '10', '0', '河南');
INSERT INTO `diqu` VALUES ('许昌', '39', '0', '2', '0', '河南');
INSERT INTO `diqu` VALUES ('漯河', '35', '1', '6', '0', '河南');
INSERT INTO `diqu` VALUES ('焦作', '32', '0', '1', '1', '河南');
INSERT INTO `diqu` VALUES ('洛阳', '31', '0', '2', '0', '河南');
INSERT INTO `diqu` VALUES ('开封', '26', '0', '1', '0', '河南');
INSERT INTO `diqu` VALUES ('鹤壁', '19', '0', '3', '0', '河南');
INSERT INTO `diqu` VALUES ('濮阳', '17', '0', '1', '0', '河南');
INSERT INTO `diqu` VALUES ('三门峡', '7', '0', '3', '0', '河南');
INSERT INTO `diqu` VALUES ('济源示范区', '5', '0', '0', '0', '河南');
INSERT INTO `diqu` VALUES ('地区待确认', '0', '0', '424', '9', '河南');
INSERT INTO `diqu` VALUES ('温州', '504', '0', '228', '0', '浙江');
INSERT INTO `diqu` VALUES ('杭州', '169', '1', '108', '0', '浙江');
INSERT INTO `diqu` VALUES ('宁波', '156', '0', '91', '0', '浙江');
INSERT INTO `diqu` VALUES ('台州', '146', '0', '74', '0', '浙江');
INSERT INTO `diqu` VALUES ('金华', '55', '0', '33', '0', '浙江');
INSERT INTO `diqu` VALUES ('嘉兴', '45', '1', '20', '0', '浙江');
INSERT INTO `diqu` VALUES ('绍兴', '42', '0', '20', '0', '浙江');
INSERT INTO `diqu` VALUES ('衢州', '21', '0', '10', '0', '浙江');
INSERT INTO `diqu` VALUES ('丽水', '17', '0', '14', '0', '浙江');
INSERT INTO `diqu` VALUES ('湖州', '10', '0', '6', '0', '浙江');
INSERT INTO `diqu` VALUES ('舟山', '10', '0', '5', '0', '浙江');
INSERT INTO `diqu` VALUES ('长沙', '242', '1', '110', '2', '湖南');
INSERT INTO `diqu` VALUES ('岳阳', '156', '1', '64', '1', '湖南');
INSERT INTO `diqu` VALUES ('邵阳', '102', '0', '71', '1', '湖南');
INSERT INTO `diqu` VALUES ('常德', '79', '0', '49', '0', '湖南');
INSERT INTO `diqu` VALUES ('株洲', '78', '0', '40', '0', '湖南');
INSERT INTO `diqu` VALUES ('娄底', '76', '0', '51', '0', '湖南');
INSERT INTO `diqu` VALUES ('益阳', '59', '0', '35', '0', '湖南');
INSERT INTO `diqu` VALUES ('衡阳', '48', '0', '32', '0', '湖南');
INSERT INTO `diqu` VALUES ('永州', '43', '0', '30', '0', '湖南');
INSERT INTO `diqu` VALUES ('怀化', '40', '0', '38', '0', '湖南');
INSERT INTO `diqu` VALUES ('郴州', '39', '0', '29', '0', '湖南');
INSERT INTO `diqu` VALUES ('湘潭', '35', '0', '17', '0', '湖南');
INSERT INTO `diqu` VALUES ('湘西自治州', '8', '0', '7', '0', '湖南');
INSERT INTO `diqu` VALUES ('张家界', '5', '0', '5', '0', '湖南');
INSERT INTO `diqu` VALUES ('合肥', '173', '0', '86', '1', '安徽');
INSERT INTO `diqu` VALUES ('蚌埠', '160', '1', '56', '5', '安徽');
INSERT INTO `diqu` VALUES ('阜阳', '155', '0', '79', '0', '安徽');
INSERT INTO `diqu` VALUES ('亳州', '108', '0', '65', '0', '安徽');
INSERT INTO `diqu` VALUES ('安庆', '83', '0', '53', '0', '安徽');
INSERT INTO `diqu` VALUES ('六安', '69', '0', '35', '0', '安徽');
INSERT INTO `diqu` VALUES ('宿州', '41', '0', '22', '0', '安徽');
INSERT INTO `diqu` VALUES ('马鞍山', '37', '0', '15', '0', '安徽');
INSERT INTO `diqu` VALUES ('芜湖', '33', '0', '21', '0', '安徽');
INSERT INTO `diqu` VALUES ('铜陵', '29', '0', '12', '0', '安徽');
INSERT INTO `diqu` VALUES ('淮北', '27', '0', '14', '0', '安徽');
INSERT INTO `diqu` VALUES ('淮南', '27', '0', '14', '0', '安徽');
INSERT INTO `diqu` VALUES ('池州', '17', '0', '10', '0', '安徽');
INSERT INTO `diqu` VALUES ('滁州', '13', '0', '8', '0', '安徽');
INSERT INTO `diqu` VALUES ('黄山', '9', '0', '6', '0', '安徽');
INSERT INTO `diqu` VALUES ('宣城', '6', '0', '4', '0', '安徽');
INSERT INTO `diqu` VALUES ('南昌', '229', '0', '133', '0', '江西');
INSERT INTO `diqu` VALUES ('新余', '130', '1', '68', '0', '江西');
INSERT INTO `diqu` VALUES ('上饶', '123', '0', '55', '0', '江西');
INSERT INTO `diqu` VALUES ('九江', '118', '0', '44', '0', '江西');
INSERT INTO `diqu` VALUES ('宜春', '106', '0', '42', '0', '江西');
INSERT INTO `diqu` VALUES ('赣州', '76', '0', '28', '1', '江西');
INSERT INTO `diqu` VALUES ('抚州', '72', '0', '35', '0', '江西');
INSERT INTO `diqu` VALUES ('萍乡', '33', '0', '9', '0', '江西');
INSERT INTO `diqu` VALUES ('吉安', '22', '0', '11', '0', '江西');
INSERT INTO `diqu` VALUES ('鹰潭', '18', '0', '4', '0', '江西');
INSERT INTO `diqu` VALUES ('景德镇', '6', '0', '3', '0', '江西');
INSERT INTO `diqu` VALUES ('赣江新区', '1', '0', '0', '0', '江西');
INSERT INTO `diqu` VALUES ('南京', '93', '0', '38', '0', '江苏');
INSERT INTO `diqu` VALUES ('苏州', '87', '0', '33', '0', '江苏');
INSERT INTO `diqu` VALUES ('徐州', '79', '0', '51', '0', '江苏');
INSERT INTO `diqu` VALUES ('淮安', '66', '0', '32', '0', '江苏');
INSERT INTO `diqu` VALUES ('无锡', '55', '0', '33', '0', '江苏');
INSERT INTO `diqu` VALUES ('常州', '51', '0', '27', '0', '江苏');
INSERT INTO `diqu` VALUES ('连云港', '48', '0', '18', '0', '江苏');
INSERT INTO `diqu` VALUES ('南通', '40', '0', '23', '0', '江苏');
INSERT INTO `diqu` VALUES ('泰州', '37', '0', '24', '0', '江苏');
INSERT INTO `diqu` VALUES ('盐城', '27', '0', '20', '0', '江苏');
INSERT INTO `diqu` VALUES ('扬州', '23', '0', '11', '0', '江苏');
INSERT INTO `diqu` VALUES ('宿迁', '13', '0', '7', '0', '江苏');
INSERT INTO `diqu` VALUES ('镇江', '12', '0', '8', '0', '江苏');
INSERT INTO `diqu` VALUES ('万州区', '113', '3', '46', '3', '重庆');
INSERT INTO `diqu` VALUES ('江北区', '28', '0', '9', '0', '重庆');
INSERT INTO `diqu` VALUES ('云阳县', '25', '0', '17', '0', '重庆');
INSERT INTO `diqu` VALUES ('綦江区', '23', '0', '11', '0', '重庆');
INSERT INTO `diqu` VALUES ('合川区', '23', '0', '8', '0', '重庆');
INSERT INTO `diqu` VALUES ('奉节县', '22', '2', '9', '0', '重庆');
INSERT INTO `diqu` VALUES ('长寿区', '21', '0', '10', '0', '重庆');
INSERT INTO `diqu` VALUES ('开州区', '20', '0', '14', '1', '重庆');
INSERT INTO `diqu` VALUES ('渝中区', '20', '0', '14', '0', '重庆');
INSERT INTO `diqu` VALUES ('垫江县', '20', '0', '9', '0', '重庆');
INSERT INTO `diqu` VALUES ('九龙坡区', '20', '0', '10', '1', '重庆');
INSERT INTO `diqu` VALUES ('忠县', '20', '0', '13', '0', '重庆');
INSERT INTO `diqu` VALUES ('潼南区', '18', '0', '4', '0', '重庆');
INSERT INTO `diqu` VALUES ('两江新区', '17', '0', '7', '0', '重庆');
INSERT INTO `diqu` VALUES ('渝北区', '16', '0', '9', '0', '重庆');
INSERT INTO `diqu` VALUES ('南岸区', '15', '0', '5', '0', '重庆');
INSERT INTO `diqu` VALUES ('大足区', '14', '0', '9', '0', '重庆');
INSERT INTO `diqu` VALUES ('石柱县', '14', '0', '8', '0', '重庆');
INSERT INTO `diqu` VALUES ('巫溪县', '13', '0', '9', '0', '重庆');
INSERT INTO `diqu` VALUES ('丰都县', '10', '0', '3', '0', '重庆');
INSERT INTO `diqu` VALUES ('巫山县', '10', '0', '6', '0', '重庆');
INSERT INTO `diqu` VALUES ('荣昌区', '9', '0', '5', '0', '重庆');
INSERT INTO `diqu` VALUES ('璧山区', '9', '0', '7', '0', '重庆');
INSERT INTO `diqu` VALUES ('铜梁区', '9', '0', '4', '0', '重庆');
INSERT INTO `diqu` VALUES ('沙坪坝区', '8', '0', '1', '0', '重庆');
INSERT INTO `diqu` VALUES ('大渡口区', '7', '0', '5', '0', '重庆');
INSERT INTO `diqu` VALUES ('巴南区', '6', '0', '2', '0', '重庆');
INSERT INTO `diqu` VALUES ('永川区', '5', '0', '4', '0', '重庆');
INSERT INTO `diqu` VALUES ('高新区', '4', '0', '1', '0', '重庆');
INSERT INTO `diqu` VALUES ('江津区', '4', '0', '3', '0', '重庆');
INSERT INTO `diqu` VALUES ('梁平区', '4', '0', '4', '0', '重庆');
INSERT INTO `diqu` VALUES ('涪陵区', '3', '0', '2', '0', '重庆');
INSERT INTO `diqu` VALUES ('彭水县', '2', '0', '0', '0', '重庆');
INSERT INTO `diqu` VALUES ('城口县', '2', '0', '2', '0', '重庆');
INSERT INTO `diqu` VALUES ('黔江区', '2', '0', '2', '0', '重庆');
INSERT INTO `diqu` VALUES ('万盛经开区', '1', '0', '0', '0', '重庆');
INSERT INTO `diqu` VALUES ('酉阳县', '1', '0', '0', '0', '重庆');
INSERT INTO `diqu` VALUES ('武隆区', '1', '0', '1', '0', '重庆');
INSERT INTO `diqu` VALUES ('秀山县', '1', '0', '1', '0', '重庆');
INSERT INTO `diqu` VALUES ('青岛', '59', '0', '29', '1', '山东');
INSERT INTO `diqu` VALUES ('济宁', '52', '0', '27', '0', '山东');
INSERT INTO `diqu` VALUES ('临沂', '49', '1', '41', '0', '山东');
INSERT INTO `diqu` VALUES ('烟台', '47', '0', '15', '0', '山东');
INSERT INTO `diqu` VALUES ('济南', '47', '0', '17', '0', '山东');
INSERT INTO `diqu` VALUES ('潍坊', '44', '0', '15', '0', '山东');
INSERT INTO `diqu` VALUES ('威海', '38', '0', '11', '0', '山东');
INSERT INTO `diqu` VALUES ('聊城', '38', '0', '18', '0', '山东');
INSERT INTO `diqu` VALUES ('德州', '37', '0', '9', '2', '山东');
INSERT INTO `diqu` VALUES ('泰安', '33', '1', '9', '1', '山东');
INSERT INTO `diqu` VALUES ('淄博', '29', '0', '6', '0', '山东');
INSERT INTO `diqu` VALUES ('枣庄', '24', '0', '10', '0', '山东');
INSERT INTO `diqu` VALUES ('菏泽', '18', '0', '13', '0', '山东');
INSERT INTO `diqu` VALUES ('日照', '16', '0', '7', '0', '山东');
INSERT INTO `diqu` VALUES ('滨州', '15', '0', '11', '0', '山东');
INSERT INTO `diqu` VALUES ('成都', '141', '0', '69', '3', '四川');
INSERT INTO `diqu` VALUES ('甘孜', '67', '2', '8', '0', '四川');
INSERT INTO `diqu` VALUES ('达州', '40', '0', '11', '0', '四川');
INSERT INTO `diqu` VALUES ('南充', '38', '0', '14', '0', '四川');
INSERT INTO `diqu` VALUES ('广安', '30', '0', '19', '0', '四川');
INSERT INTO `diqu` VALUES ('泸州', '24', '4', '5', '0', '四川');
INSERT INTO `diqu` VALUES ('巴中', '24', '0', '3', '0', '四川');
INSERT INTO `diqu` VALUES ('内江', '22', '0', '6', '0', '四川');
INSERT INTO `diqu` VALUES ('绵阳', '22', '0', '10', '0', '四川');
INSERT INTO `diqu` VALUES ('德阳', '17', '0', '1', '0', '四川');
INSERT INTO `diqu` VALUES ('遂宁', '17', '0', '10', '0', '四川');
INSERT INTO `diqu` VALUES ('攀枝花', '16', '0', '11', '0', '四川');
INSERT INTO `diqu` VALUES ('凉山', '13', '0', '5', '0', '四川');
INSERT INTO `diqu` VALUES ('宜宾', '12', '0', '7', '0', '四川');
INSERT INTO `diqu` VALUES ('自贡', '9', '0', '4', '0', '四川');
INSERT INTO `diqu` VALUES ('眉山', '8', '0', '3', '0', '四川');
INSERT INTO `diqu` VALUES ('雅安', '7', '0', '3', '0', '四川');
INSERT INTO `diqu` VALUES ('广元', '6', '0', '4', '0', '四川');
INSERT INTO `diqu` VALUES ('资阳', '3', '0', '2', '0', '四川');
INSERT INTO `diqu` VALUES ('乐山', '3', '0', '2', '0', '四川');
INSERT INTO `diqu` VALUES ('阿坝', '1', '0', '1', '0', '四川');
INSERT INTO `diqu` VALUES ('哈尔滨', '194', '2', '48', '3', '黑龙江');
INSERT INTO `diqu` VALUES ('双鸭山', '52', '0', '8', '3', '黑龙江');
INSERT INTO `diqu` VALUES ('绥化', '47', '0', '18', '4', '黑龙江');
INSERT INTO `diqu` VALUES ('鸡西', '46', '0', '3', '0', '黑龙江');
INSERT INTO `diqu` VALUES ('齐齐哈尔', '43', '0', '11', '1', '黑龙江');
INSERT INTO `diqu` VALUES ('大庆', '26', '3', '7', '1', '黑龙江');
INSERT INTO `diqu` VALUES ('七台河', '17', '0', '6', '0', '黑龙江');
INSERT INTO `diqu` VALUES ('佳木斯', '15', '0', '14', '0', '黑龙江');
INSERT INTO `diqu` VALUES ('黑河', '14', '0', '3', '0', '黑龙江');
INSERT INTO `diqu` VALUES ('牡丹江', '14', '1', '1', '0', '黑龙江');
INSERT INTO `diqu` VALUES ('鹤岗', '5', '0', '2', '0', '黑龙江');
INSERT INTO `diqu` VALUES ('大兴安岭', '2', '0', '2', '0', '黑龙江');
INSERT INTO `diqu` VALUES ('伊春', '1', '0', '0', '0', '黑龙江');
INSERT INTO `diqu` VALUES ('海淀', '61', '0', '0', '0', '北京');
INSERT INTO `diqu` VALUES ('朝阳', '58', '0', '0', '0', '北京');
INSERT INTO `diqu` VALUES ('西城', '53', '1', '0', '0', '北京');
INSERT INTO `diqu` VALUES ('丰台', '40', '0', '0', '0', '北京');
INSERT INTO `diqu` VALUES ('大兴', '39', '0', '0', '0', '北京');
INSERT INTO `diqu` VALUES ('昌平', '29', '0', '0', '0', '北京');
INSERT INTO `diqu` VALUES ('外地来京', '26', '0', '0', '0', '北京');
INSERT INTO `diqu` VALUES ('通州', '19', '1', '0', '0', '北京');
INSERT INTO `diqu` VALUES ('房山', '16', '0', '0', '0', '北京');
INSERT INTO `diqu` VALUES ('石景山', '14', '0', '0', '0', '北京');
INSERT INTO `diqu` VALUES ('东城', '12', '0', '0', '0', '北京');
INSERT INTO `diqu` VALUES ('顺义', '10', '0', '0', '0', '北京');
INSERT INTO `diqu` VALUES ('密云', '7', '0', '0', '0', '北京');
INSERT INTO `diqu` VALUES ('怀柔', '7', '0', '0', '0', '北京');
INSERT INTO `diqu` VALUES ('门头沟', '3', '0', '0', '0', '北京');
INSERT INTO `diqu` VALUES ('延庆', '1', '0', '0', '0', '北京');
INSERT INTO `diqu` VALUES ('地区待确认', '0', '0', '153', '4', '北京');
INSERT INTO `diqu` VALUES ('外地来沪', '110', '0', '66', '0', '上海');
INSERT INTO `diqu` VALUES ('浦东', '60', '0', '37', '0', '上海');
INSERT INTO `diqu` VALUES ('宝山', '21', '0', '7', '0', '上海');
INSERT INTO `diqu` VALUES ('闵行', '18', '0', '14', '0', '上海');
INSERT INTO `diqu` VALUES ('徐汇', '18', '0', '8', '0', '上海');
INSERT INTO `diqu` VALUES ('静安', '16', '0', '10', '0', '上海');
INSERT INTO `diqu` VALUES ('松江', '14', '0', '7', '0', '上海');
INSERT INTO `diqu` VALUES ('长宁', '13', '0', '8', '0', '上海');
INSERT INTO `diqu` VALUES ('普陀', '11', '0', '5', '0', '上海');
INSERT INTO `diqu` VALUES ('杨浦', '9', '0', '4', '0', '上海');
INSERT INTO `diqu` VALUES ('奉贤', '9', '0', '3', '0', '上海');
INSERT INTO `diqu` VALUES ('嘉定', '9', '0', '2', '0', '上海');
INSERT INTO `diqu` VALUES ('虹口', '7', '0', '4', '0', '上海');
INSERT INTO `diqu` VALUES ('黄浦', '6', '0', '2', '0', '上海');
INSERT INTO `diqu` VALUES ('青浦', '5', '0', '5', '0', '上海');
INSERT INTO `diqu` VALUES ('崇明', '4', '0', '2', '0', '上海');
INSERT INTO `diqu` VALUES ('金山', '3', '0', '2', '0', '上海');
INSERT INTO `diqu` VALUES ('地区待确认', '0', '0', '0', '2', '上海');
INSERT INTO `diqu` VALUES ('唐山', '56', '1', '13', '1', '河北');
INSERT INTO `diqu` VALUES ('沧州', '48', '0', '18', '3', '河北');
INSERT INTO `diqu` VALUES ('张家口', '34', '0', '24', '0', '河北');
INSERT INTO `diqu` VALUES ('保定', '32', '0', '27', '0', '河北');
INSERT INTO `diqu` VALUES ('邯郸', '31', '0', '13', '0', '河北');
INSERT INTO `diqu` VALUES ('廊坊', '30', '0', '20', '0', '河北');
INSERT INTO `diqu` VALUES ('石家庄', '28', '0', '13', '0', '河北');
INSERT INTO `diqu` VALUES ('邢台', '23', '0', '10', '1', '河北');
INSERT INTO `diqu` VALUES ('秦皇岛', '10', '0', '4', '0', '河北');
INSERT INTO `diqu` VALUES ('衡水', '8', '0', '6', '0', '河北');
INSERT INTO `diqu` VALUES ('承德', '7', '0', '4', '0', '河北');
INSERT INTO `diqu` VALUES ('福州', '71', '0', '33', '1', '福建');
INSERT INTO `diqu` VALUES ('莆田', '55', '0', '19', '0', '福建');
INSERT INTO `diqu` VALUES ('泉州', '46', '0', '13', '0', '福建');
INSERT INTO `diqu` VALUES ('厦门', '35', '0', '10', '0', '福建');
INSERT INTO `diqu` VALUES ('宁德', '26', '0', '12', '0', '福建');
INSERT INTO `diqu` VALUES ('漳州', '20', '0', '11', '0', '福建');
INSERT INTO `diqu` VALUES ('南平', '20', '0', '8', '0', '福建');
INSERT INTO `diqu` VALUES ('三明', '14', '0', '5', '0', '福建');
INSERT INTO `diqu` VALUES ('龙岩', '6', '0', '1', '0', '福建');
INSERT INTO `diqu` VALUES ('地区待确认', '0', '0', '0', '0', '福建');
INSERT INTO `diqu` VALUES ('西安', '120', '2', '0', '0', '陕西');
INSERT INTO `diqu` VALUES ('安康', '26', '1', '0', '0', '陕西');
INSERT INTO `diqu` VALUES ('汉中', '26', '0', '0', '0', '陕西');
INSERT INTO `diqu` VALUES ('咸阳', '17', '0', '0', '0', '陕西');
INSERT INTO `diqu` VALUES ('渭南', '15', '0', '0', '0', '陕西');
INSERT INTO `diqu` VALUES ('宝鸡', '13', '0', '0', '0', '陕西');
INSERT INTO `diqu` VALUES ('延安', '8', '0', '0', '0', '陕西');
INSERT INTO `diqu` VALUES ('铜川', '8', '0', '0', '0', '陕西');
INSERT INTO `diqu` VALUES ('商洛', '7', '0', '0', '0', '陕西');
INSERT INTO `diqu` VALUES ('榆林', '3', '0', '0', '0', '陕西');
INSERT INTO `diqu` VALUES ('韩城', '1', '0', '0', '0', '陕西');
INSERT INTO `diqu` VALUES ('杨凌', '1', '0', '0', '0', '陕西');
INSERT INTO `diqu` VALUES ('地区待确认', '0', '0', '105', '1', '陕西');
INSERT INTO `diqu` VALUES ('南宁', '54', '0', '23', '0', '广西');
INSERT INTO `diqu` VALUES ('北海', '44', '0', '14', '1', '广西');
INSERT INTO `diqu` VALUES ('桂林', '31', '0', '15', '0', '广西');
INSERT INTO `diqu` VALUES ('柳州', '24', '0', '10', '0', '广西');
INSERT INTO `diqu` VALUES ('河池', '23', '0', '4', '1', '广西');
INSERT INTO `diqu` VALUES ('防城港', '19', '1', '6', '0', '广西');
INSERT INTO `diqu` VALUES ('来宾', '11', '0', '0', '0', '广西');
INSERT INTO `diqu` VALUES ('玉林', '11', '0', '4', '0', '广西');
INSERT INTO `diqu` VALUES ('贵港', '8', '0', '3', '0', '广西');
INSERT INTO `diqu` VALUES ('钦州', '8', '0', '1', '0', '广西');
INSERT INTO `diqu` VALUES ('梧州', '5', '0', '5', '0', '广西');
INSERT INTO `diqu` VALUES ('贺州', '4', '0', '0', '0', '广西');
INSERT INTO `diqu` VALUES ('百色', '3', '0', '2', '0', '广西');
INSERT INTO `diqu` VALUES ('崇左', '0', '0', '0', '0', '广西');
INSERT INTO `diqu` VALUES ('昆明', '52', '0', '15', '0', '云南');
INSERT INTO `diqu` VALUES ('昭通市', '25', '0', '2', '0', '云南');
INSERT INTO `diqu` VALUES ('西双版纳州', '15', '0', '4', '0', '云南');
INSERT INTO `diqu` VALUES ('玉溪', '14', '0', '3', '1', '云南');
INSERT INTO `diqu` VALUES ('曲靖', '13', '0', '6', '0', '云南');
INSERT INTO `diqu` VALUES ('大理', '13', '0', '10', '0', '云南');
INSERT INTO `diqu` VALUES ('保山市', '9', '0', '3', '0', '云南');
INSERT INTO `diqu` VALUES ('红河', '8', '0', '3', '0', '云南');
INSERT INTO `diqu` VALUES ('丽江市', '7', '0', '7', '0', '云南');
INSERT INTO `diqu` VALUES ('德宏州', '5', '0', '2', '0', '云南');
INSERT INTO `diqu` VALUES ('普洱', '4', '0', '3', '0', '云南');
INSERT INTO `diqu` VALUES ('楚雄州', '4', '0', '1', '0', '云南');
INSERT INTO `diqu` VALUES ('文山州', '2', '0', '0', '0', '云南');
INSERT INTO `diqu` VALUES ('临沧', '1', '0', '1', '0', '云南');
INSERT INTO `diqu` VALUES ('三亚', '54', '0', '22', '1', '海南');
INSERT INTO `diqu` VALUES ('海口', '39', '5', '18', '0', '海南');
INSERT INTO `diqu` VALUES ('儋州', '15', '0', '11', '0', '海南');
INSERT INTO `diqu` VALUES ('万宁', '13', '0', '9', '0', '海南');
INSERT INTO `diqu` VALUES ('澄迈县', '9', '0', '4', '1', '海南');
INSERT INTO `diqu` VALUES ('昌江县', '7', '0', '2', '0', '海南');
INSERT INTO `diqu` VALUES ('琼海', '6', '0', '4', '1', '海南');
INSERT INTO `diqu` VALUES ('临高县', '6', '0', '4', '0', '海南');
INSERT INTO `diqu` VALUES ('陵水县', '4', '0', '1', '0', '海南');
INSERT INTO `diqu` VALUES ('文昌', '3', '0', '3', '0', '海南');
INSERT INTO `diqu` VALUES ('定安县', '3', '0', '2', '1', '海南');
INSERT INTO `diqu` VALUES ('保亭', '3', '0', '1', '0', '海南');
INSERT INTO `diqu` VALUES ('东方', '3', '0', '2', '0', '海南');
INSERT INTO `diqu` VALUES ('乐东', '2', '0', '0', '0', '海南');
INSERT INTO `diqu` VALUES ('琼中县', '1', '0', '1', '0', '海南');
INSERT INTO `diqu` VALUES ('贵阳', '36', '0', '14', '1', '贵州');
INSERT INTO `diqu` VALUES ('遵义', '32', '0', '16', '0', '贵州');
INSERT INTO `diqu` VALUES ('毕节', '23', '0', '10', '0', '贵州');
INSERT INTO `diqu` VALUES ('黔南州', '17', '0', '7', '0', '贵州');
INSERT INTO `diqu` VALUES ('铜仁', '10', '0', '9', '0', '贵州');
INSERT INTO `diqu` VALUES ('六盘水', '10', '0', '6', '1', '贵州');
INSERT INTO `diqu` VALUES ('黔东南州', '10', '0', '4', '0', '贵州');
INSERT INTO `diqu` VALUES ('安顺', '4', '0', '1', '0', '贵州');
INSERT INTO `diqu` VALUES ('黔西南州', '4', '0', '4', '0', '贵州');
INSERT INTO `diqu` VALUES ('晋中', '36', '0', '18', '0', '山西');
INSERT INTO `diqu` VALUES ('太原', '19', '0', '10', '0', '山西');
INSERT INTO `diqu` VALUES ('运城', '19', '0', '14', '0', '山西');
INSERT INTO `diqu` VALUES ('大同', '12', '0', '6', '0', '山西');
INSERT INTO `diqu` VALUES ('晋城', '10', '0', '3', '0', '山西');
INSERT INTO `diqu` VALUES ('朔州', '8', '0', '3', '0', '山西');
INSERT INTO `diqu` VALUES ('长治', '8', '0', '1', '0', '山西');
INSERT INTO `diqu` VALUES ('忻州', '7', '0', '4', '0', '山西');
INSERT INTO `diqu` VALUES ('吕梁', '6', '0', '6', '0', '山西');
INSERT INTO `diqu` VALUES ('阳泉', '4', '0', '2', '0', '山西');
INSERT INTO `diqu` VALUES ('临汾', '2', '0', '1', '0', '山西');
INSERT INTO `diqu` VALUES ('宝坻区', '55', '2', '15', '0', '天津');
INSERT INTO `diqu` VALUES ('河东区', '15', '0', '7', '0', '天津');
INSERT INTO `diqu` VALUES ('河北区', '12', '0', '9', '0', '天津');
INSERT INTO `diqu` VALUES ('外地来津', '6', '0', '4', '0', '天津');
INSERT INTO `diqu` VALUES ('南开区', '6', '0', '1', '0', '天津');
INSERT INTO `diqu` VALUES ('和平区', '6', '0', '4', '0', '天津');
INSERT INTO `diqu` VALUES ('北辰区', '6', '0', '1', '0', '天津');
INSERT INTO `diqu` VALUES ('河西区', '4', '0', '2', '0', '天津');
INSERT INTO `diqu` VALUES ('宁河区', '4', '0', '0', '0', '天津');
INSERT INTO `diqu` VALUES ('西青区', '4', '0', '4', '0', '天津');
INSERT INTO `diqu` VALUES ('东丽区', '4', '0', '2', '0', '天津');
INSERT INTO `diqu` VALUES ('滨海新区', '3', '0', '1', '0', '天津');
INSERT INTO `diqu` VALUES ('红桥区', '2', '0', '2', '0', '天津');
INSERT INTO `diqu` VALUES ('武清区', '2', '0', '1', '0', '天津');
INSERT INTO `diqu` VALUES ('津南区', '1', '0', '1', '0', '天津');
INSERT INTO `diqu` VALUES ('地区待确认', '0', '0', '0', '3', '天津');
INSERT INTO `diqu` VALUES ('沈阳', '28', '0', '11', '0', '辽宁');
INSERT INTO `diqu` VALUES ('大连', '19', '0', '9', '0', '辽宁');
INSERT INTO `diqu` VALUES ('葫芦岛', '12', '0', '4', '1', '辽宁');
INSERT INTO `diqu` VALUES ('锦州', '12', '0', '7', '0', '辽宁');
INSERT INTO `diqu` VALUES ('盘锦', '11', '0', '4', '0', '辽宁');
INSERT INTO `diqu` VALUES ('阜新', '8', '0', '6', '0', '辽宁');
INSERT INTO `diqu` VALUES ('铁岭', '7', '0', '2', '0', '辽宁');
INSERT INTO `diqu` VALUES ('丹东', '7', '0', '5', '0', '辽宁');
INSERT INTO `diqu` VALUES ('朝阳市', '6', '0', '3', '0', '辽宁');
INSERT INTO `diqu` VALUES ('鞍山', '4', '0', '0', '0', '辽宁');
INSERT INTO `diqu` VALUES ('辽阳', '3', '0', '3', '0', '辽宁');
INSERT INTO `diqu` VALUES ('本溪', '3', '0', '3', '0', '辽宁');
INSERT INTO `diqu` VALUES ('营口', '1', '0', '1', '0', '辽宁');
INSERT INTO `diqu` VALUES ('长春', '45', '0', '19', '0', '吉林');
INSERT INTO `diqu` VALUES ('四平', '15', '0', '7', '1', '吉林');
INSERT INTO `diqu` VALUES ('辽源', '7', '0', '1', '0', '吉林');
INSERT INTO `diqu` VALUES ('公主岭', '6', '0', '2', '0', '吉林');
INSERT INTO `diqu` VALUES ('吉林', '5', '0', '3', '0', '吉林');
INSERT INTO `diqu` VALUES ('延边', '5', '0', '4', '0', '吉林');
INSERT INTO `diqu` VALUES ('通化', '4', '1', '1', '0', '吉林');
INSERT INTO `diqu` VALUES ('松原', '2', '0', '2', '0', '吉林');
INSERT INTO `diqu` VALUES ('梅河口市', '1', '0', '1', '0', '吉林');
INSERT INTO `diqu` VALUES ('白城', '1', '0', '0', '0', '吉林');
INSERT INTO `diqu` VALUES ('兰州', '36', '0', '23', '2', '甘肃');
INSERT INTO `diqu` VALUES ('天水', '12', '0', '11', '0', '甘肃');
INSERT INTO `diqu` VALUES ('平凉', '9', '0', '3', '0', '甘肃');
INSERT INTO `diqu` VALUES ('定西', '9', '0', '8', '0', '甘肃');
INSERT INTO `diqu` VALUES ('甘南州', '8', '0', '4', '0', '甘肃');
INSERT INTO `diqu` VALUES ('陇南', '4', '0', '4', '0', '甘肃');
INSERT INTO `diqu` VALUES ('白银', '4', '0', '1', '0', '甘肃');
INSERT INTO `diqu` VALUES ('临夏', '3', '0', '3', '0', '甘肃');
INSERT INTO `diqu` VALUES ('庆阳', '3', '0', '2', '0', '甘肃');
INSERT INTO `diqu` VALUES ('张掖', '2', '0', '2', '0', '甘肃');
INSERT INTO `diqu` VALUES ('金昌', '1', '0', '1', '0', '甘肃');
INSERT INTO `diqu` VALUES ('地区待确定', '0', '0', '3', '0', null);
INSERT INTO `diqu` VALUES ('乌鲁木齐', '23', '0', '8', '0', '乌鲁木齐');
INSERT INTO `diqu` VALUES ('伊犁州', '18', '0', '6', '0', '乌鲁木齐');
INSERT INTO `diqu` VALUES ('兵团第四师', '10', '0', '0', '0', '乌鲁木齐');
INSERT INTO `diqu` VALUES ('昌吉州', '4', '0', '2', '0', '乌鲁木齐');
INSERT INTO `diqu` VALUES ('兵团第九师', '4', '0', '0', '0', '乌鲁木齐');
INSERT INTO `diqu` VALUES ('第八师石河子', '4', '0', '1', '1', '乌鲁木齐');
INSERT INTO `diqu` VALUES ('兵团第十二师', '3', '0', '0', '0', '乌鲁木齐');
INSERT INTO `diqu` VALUES ('巴州', '3', '0', '0', '0', '乌鲁木齐');
INSERT INTO `diqu` VALUES ('吐鲁番', '3', '0', '1', '0', '乌鲁木齐');
INSERT INTO `diqu` VALUES ('六师五家渠', '2', '0', '0', '0', '乌鲁木齐');
INSERT INTO `diqu` VALUES ('第七师', '1', '0', '1', '0', '乌鲁木齐');
INSERT INTO `diqu` VALUES ('阿克苏', '1', '0', '1', '0', '乌鲁木齐');
INSERT INTO `diqu` VALUES ('包头', '11', '0', '1', '0', '内蒙古');
INSERT INTO `diqu` VALUES ('鄂尔多斯', '11', '0', '3', '0', '内蒙古');
INSERT INTO `diqu` VALUES ('赤峰', '9', '0', '3', '0', '内蒙古');
INSERT INTO `diqu` VALUES ('锡林郭勒', '9', '0', '1', '0', '内蒙古');
INSERT INTO `diqu` VALUES ('巴彦淖尔', '8', '0', '0', '0', '内蒙古');
INSERT INTO `diqu` VALUES ('呼伦贝尔', '7', '0', '1', '0', '内蒙古');
INSERT INTO `diqu` VALUES ('通辽', '7', '0', '0', '0', '内蒙古');
INSERT INTO `diqu` VALUES ('呼和浩特', '7', '0', '1', '0', '内蒙古');
INSERT INTO `diqu` VALUES ('乌兰察布', '3', '0', '1', '0', '内蒙古');
INSERT INTO `diqu` VALUES ('乌海', '2', '0', '0', '0', '内蒙古');
INSERT INTO `diqu` VALUES ('兴安盟乌兰浩特', '1', '0', '0', '0', '内蒙古');
INSERT INTO `diqu` VALUES ('银川', '33', '0', '25', '0', '宁夏');
INSERT INTO `diqu` VALUES ('吴忠', '28', '0', '9', '0', '宁夏');
INSERT INTO `diqu` VALUES ('固原', '5', '0', '3', '0', '宁夏');
INSERT INTO `diqu` VALUES ('中卫', '3', '0', '3', '0', '宁夏');
INSERT INTO `diqu` VALUES ('石嘴山', '1', '0', '1', '0', '宁夏');
INSERT INTO `diqu` VALUES ('宁东管委会', '1', '0', '1', '0', '宁夏');
INSERT INTO `diqu` VALUES ('地区待确认', '65', '3', '5', '2', '香港');
INSERT INTO `diqu` VALUES ('地区待确认', '24', '2', '2', '1', '台湾');
INSERT INTO `diqu` VALUES ('西宁', '15', '0', '3', '0', '青海');
INSERT INTO `diqu` VALUES ('海北州', '3', '0', '0', '0', '青海');
INSERT INTO `diqu` VALUES ('地区待确认', '0', '0', '13', '0', '青海');
INSERT INTO `diqu` VALUES ('地区待确认', '10', '0', '6', '0', '澳门');
INSERT INTO `diqu` VALUES ('地区待确认', '1', '0', '1', '0', '西藏');

-- ----------------------------
-- Table structure for feiyansheng
-- ----------------------------
DROP TABLE IF EXISTS `feiyansheng`;
CREATE TABLE `feiyansheng` (
  `name` varchar(255) DEFAULT NULL,
  `totalconfirm` varchar(255) DEFAULT NULL,
  `todayconfirm` varchar(255) DEFAULT NULL,
  `totalheal` varchar(255) DEFAULT NULL,
  `totaldead` varchar(255) DEFAULT NULL,
  `emphasis` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of feiyansheng
-- ----------------------------
INSERT INTO `feiyansheng` VALUES ('湖北', '62031', '349', '10337', '2029', null);
INSERT INTO `feiyansheng` VALUES ('广东', '1332', '1', '619', '5', null);
INSERT INTO `feiyansheng` VALUES ('河南', '1265', '4', '614', '19', null);
INSERT INTO `feiyansheng` VALUES ('浙江', '1175', '2', '609', '0', null);
INSERT INTO `feiyansheng` VALUES ('湖南', '1010', '2', '578', '4', null);
INSERT INTO `feiyansheng` VALUES ('安徽', '987', '1', '500', '6', null);
INSERT INTO `feiyansheng` VALUES ('江西', '934', '1', '432', '1', null);
INSERT INTO `feiyansheng` VALUES ('江苏', '631', '0', '325', '0', null);
INSERT INTO `feiyansheng` VALUES ('重庆', '560', '5', '274', '5', null);
INSERT INTO `feiyansheng` VALUES ('山东', '546', '2', '238', '4', null);
INSERT INTO `feiyansheng` VALUES ('四川', '520', '6', '198', '3', null);
INSERT INTO `feiyansheng` VALUES ('黑龙江', '476', '6', '123', '12', null);
INSERT INTO `feiyansheng` VALUES ('北京', '395', '2', '153', '4', null);
INSERT INTO `feiyansheng` VALUES ('上海', '333', '0', '186', '2', null);
INSERT INTO `feiyansheng` VALUES ('河北', '307', '1', '152', '5', null);
INSERT INTO `feiyansheng` VALUES ('福建', '293', '0', '112', '1', null);
INSERT INTO `feiyansheng` VALUES ('陕西', '245', '3', '105', '1', null);
INSERT INTO `feiyansheng` VALUES ('广西', '245', '1', '87', '2', null);
INSERT INTO `feiyansheng` VALUES ('云南', '172', '0', '60', '1', null);
INSERT INTO `feiyansheng` VALUES ('海南', '168', '5', '84', '4', null);
INSERT INTO `feiyansheng` VALUES ('贵州', '146', '0', '71', '2', null);
INSERT INTO `feiyansheng` VALUES ('山西', '131', '0', '68', '0', null);
INSERT INTO `feiyansheng` VALUES ('天津', '130', '2', '54', '3', null);
INSERT INTO `feiyansheng` VALUES ('辽宁', '121', '0', '58', '1', null);
INSERT INTO `feiyansheng` VALUES ('吉林', '91', '1', '40', '1', null);
INSERT INTO `feiyansheng` VALUES ('甘肃', '91', '0', '65', '2', null);
INSERT INTO `feiyansheng` VALUES ('新疆', '76', '0', '20', '1', null);
INSERT INTO `feiyansheng` VALUES ('内蒙古', '75', '0', '11', '0', null);
INSERT INTO `feiyansheng` VALUES ('宁夏', '71', '0', '42', '0', null);
INSERT INTO `feiyansheng` VALUES ('香港', '65', '3', '5', '2', null);
INSERT INTO `feiyansheng` VALUES ('台湾', '24', '2', '2', '1', null);
INSERT INTO `feiyansheng` VALUES ('青海', '18', '0', '16', '0', null);
INSERT INTO `feiyansheng` VALUES ('澳门', '10', '0', '6', '0', null);
INSERT INTO `feiyansheng` VALUES ('西藏', '1', '0', '1', '0', null);

-- ----------------------------
-- Table structure for quanguo
-- ----------------------------
DROP TABLE IF EXISTS `quanguo`;
CREATE TABLE `quanguo` (
  `chinaTotalconfirm` varchar(255) DEFAULT NULL,
  `chinaAddconfirm` varchar(255) DEFAULT NULL,
  `chinaTotalsuspect` varchar(255) DEFAULT NULL,
  `chinaAddsuspect` varchar(255) DEFAULT NULL,
  `chinaTotalheal` varchar(255) DEFAULT NULL,
  `chinaAddheal` varchar(255) DEFAULT NULL,
  `chinaTotaldead` varchar(255) DEFAULT NULL,
  `chinaAdddead` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of quanguo
-- ----------------------------
INSERT INTO `quanguo` VALUES ('74675', '396', '4922', '-326', '16245', '1858', '2121', '115');
